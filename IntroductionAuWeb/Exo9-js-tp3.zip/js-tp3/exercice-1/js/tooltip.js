window.onload = function() {
	//Initialisation
let id = document.getElementById("tooltip");


	// place un message d'erreur comme contenu de l'élément
	// d'id 'tooltip' et rend cet élément visible
	function on_failure(request) {

//on affiche le message d'erreur
		id.innerHTML="ceci est un message d'erreur";

		//rendre ce message visible sur la page HTML
		id.style.visibility="visible";

	}

	// place la réponse du serveur (request.responseText)
	// comme contenu de l'élément d'id 'tooltip' et rend
	// cet élément visible
	function on_success(request) {

		//on affiche la réponse du serveur dans la balise div de l'HTML
		div.innerHTML = request.responseText;

		//on rend la réponse visible
		div.style.visibility="visible";
	}

	// supprime le contenu de l'élément d'id 'tooltip'
	// et rend cet élément caché
	function tooltip_hide() {

		//on affiche un message vide (pour ne rien afficher)
		div.innerHTML="";

		//on rend la message caché
		div.style.visibility="hidden";

	}

	// effectue la requête Ajax sur le script 'dico.php'
	// avec, comme paramètre 'word', le mot sélectionné
	// sur le double-clic et :
	//   * appelle la fonction 'on_success' en cas de succès
	//   * appelle la fonction 'on_failure' en cas d'échec
	function tooltip_show() {

		//on définit la fenêtre qui affichera:
		// -la traduction du mot trouvé dans le dico.php en cas de succès
		// -un message d'erreur en cas d'echec
		let sel = window.getSelection().getRangeAt(0);
		new simpleAjax("dico.php","get","word=" + sel ,on_success,on_failure);


	}

	// ici, il faut créer un nouvel élément 'div' avec
	// l'attribut 'id' ayant pour valeur 'tooltip', et
	// avec l'évènement 'onclick' lié à la fonction
	// 'tooltip_hide', et il faut ajouter ce nouvel élément
	// comme dernier fils de l'élément 'body'
	let div = document.createElement("div");
	div.id="tooltip";
	div.onclick=tooltip_hide;

	//ajout de l'élement 
	document.body.append(div);



	// ici, il faut ajouter l'évènement 'ondblclick' sur
	// l'élément 'body' et le ier à la fonction 'tooltip_show'
document.body.ondblclick = tooltip_show;

};
