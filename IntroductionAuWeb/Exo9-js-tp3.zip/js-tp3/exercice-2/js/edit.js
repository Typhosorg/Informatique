window.onload = function () {
  // pour stocker l'élément en cours d'édition
  var editable

  // ici, on fabrique l'éditeur et tous ses composants

  // l'élément principal
  let editor = document.createElement('div')
  // le 'textarea' dans lequel on place le contenu
  // de l'élément à éditer
  let textarea = document.createElement('textarea')
  // un paragraphe pour regrouper des éléments
  let paragraph = document.createElement('p')
  // le bouton 'save'
  let saveButton = document.createElement('input')
  saveButton.type = 'button'
  saveButton.value = 'save'
  // le bouton 'cancel'
  let cancelButton = document.createElement('input')
  cancelButton.type = 'button'
  cancelButton.value = 'cancel'
  // ici, on emboîte les éléments les uns dans les autres
  paragraph.appendChild(textarea)
  editor.appendChild(paragraph)
  editor.appendChild(saveButton)
  editor.appendChild(cancelButton)
  // on ajoute l'attribut 'id' à l'éditeur
  editor.setAttribute('id', 'editor')
  // on ajoute l'éditeur comme dernier fils du 'body'
  document.querySelector('body').appendChild(editor)
  // on cache l'éditeur
  editor.style.visibility = 'hidden'

  // la fonction liée à l'évènement 'onclick' sur
  // le bouton 'save' de l'éditeur doit :
  //   * placer le (nouveau) contenu du 'textarea'
  //     comme (nouveau) contenu de l'élément à éditer
  //   * effectue un requête AJAX au script 'edit.php' avec
  //     comme paramètres 'id' l'id de l'élément à éditer et
  //     comme paramètre 'content' le nouveau contenu
  saveButton.onclick = function () {

		//on définit l'éditeur de texte
    let editor = document.querySelector('#editor')

		//on définit de plus la zone de texte pour placer le contenu de notre texte
    let textarea = document.querySelector('#editor textarea')

		//on affiche sur l'HTML (page) le contenu de notre texte à écrire
    editable.innerHTML = textarea.value

		// soit la balise id qui prend comme valeur le contenu des données id (random)
    let id = editable.getAttribute('data-id')

		//on constitue notre requete avec le contenu de notre texte
    let request = 'id=' + id + '&' + 'content=' + editable.innerHTML

		//on utilise Ajax pour la fenêtre d'edition du message
    new simpleAjax("edit.php", 'post', request)

		//puis nous cachons l'éditeur
    editor.style.visibility = 'hidden'
  }

  // la fonction liée à l'évènement 'onclick' sur
  // le bouton 'cancel' de l'éditeur doit :
  //   * supprimer le contenu du 'textarea'
  //   * cacher l'éditeur
  cancelButton.onclick = function () {

		//on définit de plus la zone de texte pour placer le contenu de notre texte
    let textarea = document.querySelector('#editor textarea')

    // on reinitialise textarea en mettant un message vide
    textarea.innerHTML = ''

		//on définit l'éditeur de texte
    editor = document.querySelector('#editor')

		//et on le cache
    editor.style.visibility = 'hidden'
  }

  // cette fonction est appelée lors
  // d'un clic sur un élément éditable.
  // Lorsqu'elle appelée, elle doit :
  //   * stocker l'élément à éditer dans la varianle 'editable'
  //   * copier le contenu de l'élément dans le 'textarea'
  //   * faire apparaître l'éditeur
  function openEditor () {

		//editable prend la valeur this
    editable = this

		//on définit l'éditeur de texte avec la zone de texte à écrire
    let editor = document.querySelector('#editor')
    let textarea = document.querySelector('#editor textarea')

    // on remplit dans la variable textarea le contenu de innerHTML
    textarea.value = editable.innerHTML

		//on rend l'éditeur visible pendant l'éxecution de la fonction d'édition
    editor.style.visibility = 'visible'
  }

  // ici, il faut ajouter l'évènement 'onclick' sur tous les éléments de
  // classe 'editable' et lier à cet évènement la fonction 'openEditor'

	//on définit edit un tableau ou on associe les éléments d'editable
  edit = document.querySelectorAll('.editable')

	//pour chaque élément du tableau (contenu que prend editable)
  for (let i = 0; i < edit.length; i++) {

		//on édite les éléments en cliquant aux éléments correspondants
    edit[i].onclick = openEditor
  }
}
