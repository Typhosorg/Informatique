
// le tableau qui contient le chemin
// du fichier image pour chaque image
var array = [];

// si clicked[i] == true alors array[i] est visible
var clicked = [];

// pour décider si un clic est
// un premier clic ou non
var first_click = true;

// l'indice de la première image cliquée
var first_index = 0;

// le nombre total de paires de clics
var clicks_number = 0;

// the nombre de paires de clics réussis
// (les paires de clics qui ont découvert
// des images identiques)
var good_clicks_number = 0;

// affecte à l'attribut src des deux images d'indice i et j
// le source de l'image "point d'interrogation"

	function hide(i, j) {
		//soit un tableau d'images
		let images = document.querySelectorAll("img");

		//on attribut à la carte retournée l'image d'initialisation (?)
		images[i].src = "images/question-mark.png";
		images[j].src = "images/question-mark.png";
	}

	// gère le clic sur l'image d'indice n
	function click_image(n) {
		//soit un tableau d'images
		let images = document.querySelectorAll("img");

		//si nous choisissons une des images du point d'interrogation
		if (images[n].getAttribute("src") == "images/question-mark.png") {

			//si c'est le premier clic
			if (first_click) {

				// On affiche l'image de sa source
				images[n].src = array[n];

				 //On stocke la source de l'image dans un tableau associé au premier clique
				clicked[first_index] = images[n].src;

				//On stocke l'indice de l'image
				clicked[first_index+1] = n;

				//on attribut le premier clic comme valeur fausse
				first_click = false;

				// sinon si c'est le 2e clique
			} else {

				//on affiche la 2e carte depuis sa source
				images[n].src = array[n];

				//si la source de la carte 2 est identique à celle stocker dans le tableau lors du premier clic
				if (clicked[first_index] == images[n].src) {

					//on ajoute 1 au nombre de paires de cartes trouvées
					good_clicks_number += 1;

					//sinon si elles ne sont pas identiques
				} else {

					//on cache les images restés depuis affiché pendant une période d'1 seconde
					setTimeout(hide, 1000, clicked[first_index+1], n);
				}
				// Si les 8 pairs ont été trouvé
				if (good_clicks_number == 8) {

					//on définit la balise id resultat de l'HTML
					let resultat = document.getElementById("result");

					//on rend visible le résultat sur la page HTML
					resultat.style.visibility = "visible";

					//Nous afficherons le message ainsi que le nombre de clics réalisés durant la période du jeu
					resultat.innerHTML = "Félicitations ! Vous avez réaliser le jeu de mémoire en "+clicks_number+" clics !";
				}
				//dans la boucle on ajoute 1 à chaque clic
				clicks_number += 1;

				//le premier clic prend toujours la valeur vrai
				first_click = true;
			}
		}
	}

	// rempli le tableau array avec la valeur de
	// l'attribut 'name' des images
	function init() {

		//on définit le tableau d'images
		let images = document.querySelectorAll("img");

		//pour chaque cellule du tableau
		for (let i=0; i<16; i++) {

			//on l'associe à une image avec son URL
			array[i]=images[i].getAttribute("name");
		}
	}

	window.onload = init;
