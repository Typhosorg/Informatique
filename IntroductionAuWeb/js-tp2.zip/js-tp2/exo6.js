
window.onload = function () {

	// les noms des fichiers images
	var sources = ["paysage-1.jpg", "paysage-2.jpg", "paysage-3.jpg",
		"paysage-4.jpg", "paysage-5.jpg", "paysage-6.jpg",
		"paysage-7.jpg", "paysage-8.jpg", "paysage-9.jpg"];

	// l'indice de l'image actuellement visible
	var indice = 0;

	// pour stocker l'id du timer
	var handler = null;

	// affiche l'image suivante

	function next() {

		//l'indice est calculé en prenant le reste de la division euclidienne de
		//l'indice précédent par le nombre total de photos
		indice=(indice+1)%(sources.length);

		//show prend le paramêtre de la balise id show
		let show=document.getElementById("show");

		//nous construisons le lien source de l'image
		show.src="images/paysage-"+(indice+1)+".jpg";
	}

	//on associe le titre suivant
	function relancer(){
			this.title="Cliquer pour relancer le diaporama";
	}
	function stopper(){
		this.title="Cliquer pour stopper le diaporama";
	}

	// permet, alternativement, de lancer
	// ou d'arrêter le diaporama
	function startstop() {
		//si le handler est nul
		if(handler === null){

			//on continue le diaporama
			timer=setInterval(next,2000);

			//handler n'est plus nul
			handler = 1;
		}
		//sinon on arrete le diaporama
		else{
			clearInterval(timer);

			//l'image affiche le petit message de relancement
			image.onmouseover=relancer;

			//handler est null
			handler=null;
		}

	}

	// ici, on relie la fonction "startstop" à l'évènement "onclic"
	// pour l'image (l'élément d'id "show")
	// puis on lance le diaporama "automatique"
	//image prend le contenu de la blaise id
	let image = document.getElementById("show");

	//on execute le programme startstop si on clique sur l'image
	image.onclick = startstop;


};
