
window.onload = function () {

	// affiche la source de l'image cliquée dans l'image
	// d'id "realize"
	function show() {
		//bigpic prend le paramêtre de la balise show realize
		let bigpic = document.getElementById("realsize");

		//on affecte le lien de source à l'élement bigpic
		bigpic.src = this.src ;

		//titre prend le paramêtre de la balise show legend
		let titre=document.getElementById("legend");

		//on affiche le titre appartenant à l'élément associé à show
		titre.innerHTML=this.title;



	}

	// ici, il faut relier la fonction "show" à l'évènement "onmouseover"
	// sur toutes les images ayant la classe "miniature"
	//imgs prend le paramêtre de la balise classe, le tableau miniature contenant tous les photos
	let imgs=document.getElementsByClassName("miniature");

	//pour chaque image
	for(let i=0; i<(imgs.length);i++){

		//on montre l'image avec son titre associé une fois qu'on la survole
		imgs[i].onmouseover=show;
	}
}
