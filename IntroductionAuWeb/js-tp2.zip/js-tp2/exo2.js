
window.onload = function () {

    // les noms des fichiers images
    var sources = ["paysage-1.jpg", "paysage-2.jpg", "paysage-3.jpg",
        "paysage-4.jpg", "paysage-5.jpg", "paysage-6.jpg",
        "paysage-7.jpg", "paysage-8.jpg", "paysage-9.jpg"];

    // les noms des fichiers images
    var indice = 0;

    // affiche l'image suivante
    function next() {

  		//l'indice est calculé en prenant le reste de la division euclidienne de
  		//l'indice précédent par le nombre total de photos
  		indice=(indice+1)%(sources.length);

  		//show prend le paramêtre de la balise id show
  		let show=document.getElementById("show");

  		//nous construisons le lien source de l'image
  		show.src="images/paysage-"+(indice+1)+".jpg";
  	}


	// ici, il faut relier le JS à l'évènement "onclick" sur
	// l'image d'id "show"
  //image prend la balise id "show"
   let image=document.getElementById("show");

   //l'image executera le programme next lorsque nous cliquons
   image.onclick=next;
}
