window.onload = function () {

    // le "handler" du setTimeout
    let chrono = null;

    // si 'ok' est 'true', alors l'utilisateur
    // a choisi la bonne réponse
    let ok = false;
		/*function reponse(){
			if(this.hasAttribute("data-ok")){
				ok=true;
			}
			else{
				ok=false;
			}
			return ok;
		}
		reponse = reponse();
*/
    // affiche le message 'm' avec la couleur 'c'
    // dans l'élément prévu à cet effet
    function msg(m, c) {
        document.getElementById("message").innerHTML = m;
        document.getElementById("message").style.color = c;
    }

    // cette fonction est appelée à l'issue
    // du setTimeout
    function stop() {
        clearTimeout(chrono);
        chrono = null;
    }

    // traite le "clic" sur un bouton radio
    function verifier() {
        if (chrono != null) {
            if(this.hasAttribute("data-ok")){
                msg("Vous avez la BONNE réponse DANS LES TEMPS !", "green");
            }else{
                msg("Vous avez la MAUVAISE réponse ! IL RESTE DU TEMPS", "red");
            }
        }else{
            if(this.hasAttribute("data-ok")){
                msg("Vous avez la BONNE réponse MAIS LE TEMPS EST ÉCOULÉ ", "green");
            }else{
                msg("Vous avez la MAUVAISE réponse et LE TEMPS EST ÉCOULÉ ", "red");
            }
        }
    }

    chrono = setTimeout(stop, 5000);

    var input = document.querySelectorAll("input");
    for (var i = 0; i < input.length; i++) {
        input[i].onclick = verifier;
        input[i].checked = false;
    }
    // ici, on lance le setTimeout et stocke
    // le "handler" dans la variable 'chrono'

};
