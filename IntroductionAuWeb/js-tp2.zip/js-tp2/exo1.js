
window.onload = function () {

	// les noms des fichiers images
	var sources = ["paysage-1.jpg", "paysage-2.jpg", "paysage-3.jpg",
		"paysage-4.jpg", "paysage-5.jpg", "paysage-6.jpg",
		"paysage-7.jpg", "paysage-8.jpg", "paysage-9.jpg"];

	// l'indice de l'image actuellement visible
	var indice = 0;

	// affiche l'image suivante
	function next() {

		//l'indice est calculé en prenant le reste de la division euclidienne de
		//l'indice précédent par le nombre total de photos
		indice=(indice+1)%(sources.length);

		//show prend le paramêtre de la balise id show
		let show=document.getElementById("show");

		//nous construisons le lien source de l'image
		show.src="images/paysage-"+(indice+1)+".jpg";
	}

	// affiche l'image précédente
	function previous() {
		//si l'indice est 0 on affiche la 8e photos
		if (indice==0) {
			indice=8;
		}

		//si l'indice est 1 on affiche la 9e photo
		if (indice==1){
			indice=9;
		}
		else{
			//sinon on soustrait l'indice par -1 pour obtenir l'image précédente
			indice =indice-1;
		}
		//show prend le paramêtre de la balise show id
		let show=document.getElementById("show");

		//nous construisons le lien source de l'image
		show.src="images/paysage-"+indice+".jpg";

	}

	// ici, il faut relier le JS à l'évènement "onclick" sur
	// les deux "flèches" (les images)
	//fleche prend le tableau composé de plisieurs cellules classant la ligne img
	let fleche=document.querySelectorAll("img");

	//la flèche de gauche executera le programme previous lorsque nous cliquons
	fleche[0].onclick=previous;

	//la flèche de gauche executera le programme next lorsque nous cliquons
	fleche[2].onclick=next;
}
